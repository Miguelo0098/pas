#!/bin/bash
if [[ $# -lt 1 ]]; then
	echo "No se han introducido los parámetros necesarios!"
fi

function recursiva(){

}
